function [outputArg1,outputArg2] = interp_hsv(inputArg1,inputArg2)
%INTERP_HSV Summary of this function goes here
%   Detailed explanation goes here
outputArg1 = inputArg1;
outputArg2 = inputArg2;
end

